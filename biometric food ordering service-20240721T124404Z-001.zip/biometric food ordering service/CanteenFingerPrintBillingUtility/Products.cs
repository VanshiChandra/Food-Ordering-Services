﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CanteenFingerPrintBillingUtility
{
    public partial class Products : Form
    {
        bool EditMode = false;
        string ID = "";
       // string ThisShop = MySettings.Default.ThisShop;
        public Products()
        {
            InitializeComponent();
        }
        public Products(string PidOrCode)
        {
            InitializeComponent();
            LoadData(PidOrCode);
        }
        public void LoadData(string Info)
        {
            string cmd = "select * from products where pcode='" + Info + "'";
            DataTable t = new MyOleDB().ResultQuery(cmd).Tables[0];
            if (t.Rows.Count == 0) { return; }
            DataRow r = t.Rows[0];
            PNameTB.Text = r["Pname"].ToString();
            PCodeTB.Text = r["Pcode"].ToString();
            QuantityTB.Text = r["Quantity"].ToString();
            PriceTB.Text = r["Price"].ToString();
            ID = r["Pid"].ToString();
            EditMode = true;

        }
        private void Search() { Search(SearchTB.Text.Trim()); }
        private void Search(string PnameOrPCode)
        {

            string cmd = "select pid,Pname as 'Product Name',Pcode as 'Product Code',Quantity as 'Available Quantity',Price from Products where pname like '%" + PnameOrPCode + "%'  or pcode like '%" + PnameOrPCode + "%' "; 
            DataTable t = new MyOleDB().ResultQuery(cmd).Tables[0];
            if (t.Rows.Count == 0) { return; }
            dataGridViewX1.DataSource = t;
            dataGridViewX1.Columns[0].Visible = false;

        }

        private void DoneBTN_Click(object sender, EventArgs e)
        {
            if (!superValidator1.Validate()) { return; }

            string Name = PNameTB.Text.Trim();
            string code = PCodeTB.Text.Trim();
            string Quantity = QuantityTB.Text.Trim();
            string Price = PriceTB.Text.Trim();
           // string Shop = MySettings.Default.ThisShop;

            if (!EditMode)
            {
                if (new MyOleDB().OleDbScalarQuery("Select count(pcode) from Products").Equals("1")) { MessageBox.Show("Product Code Already Exist."); return; }
                string cmd = "Insert into Products(pname,pcode,quantity,price) values('" + Name + "','" + code + "'," + Quantity + "," + Price + ")";
                new MyOleDB().OleDbNonQuery(cmd);
                MessageBox.Show("Product Added");
                
            }
            else
            {
                string cmd = " Update Products set pname='" + Name + "',pcode='" + code + "',quantity =" + Quantity + " ,price =" + Price + " where pid=" + ID;
                new MyOleDB().OleDbNonQuery(cmd);
                MessageBox.Show("Product Updated");

            }

            ID = PNameTB.Text = PCodeTB.Text = QuantityTB.Text = PriceTB.Text = "";
            EditMode = false;
            SearchPCode.Enabled = PCodeTB.Enabled = true;
            Search(SearchTB.Text.Trim());

            

        }

        private void SearchPCode_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(new MyDB().TestSqlConnection().ToString());
            //MessageBox.Show(Application.StartupPath);
            LoadData(PCodeTB.Text.Trim());
        }

      

        private void buttonX1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void SearchBTN_Click(object sender, EventArgs e)
        {
            if (!superValidator1.Validate(SearchTB)) { return; }
            Search(SearchTB.Text.Trim());
            //select pid,Pname as 'Product Name',Pcode as 'Product Code',Quantity as 'Available Quantity',Price from Products where pname like '%%' or pcode like='%%'
        }

        private void dataGridViewX1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridViewX1.SelectedRows.Count == 0) { return; }
            DataGridViewRow r = dataGridViewX1.SelectedRows[0];
            ID = r.Cells["PID"].Value.ToString();
            PNameTB.Text = r.Cells[1].Value.ToString();
            PCodeTB.Text = r.Cells[2].Value.ToString();
            QuantityTB.Text = r.Cells[3].Value.ToString();
            PriceTB.Text = r.Cells[4].Value.ToString();
            EditMode = true;
            SearchPCode.Enabled = PCodeTB.Enabled = false; 
        }

        private void ResetBTN_Click(object sender, EventArgs e)
        {
            PNameTB.Text = PCodeTB.Text = QuantityTB.Text = PriceTB.Text = "";
            EditMode = false;
            SearchPCode.Enabled = PCodeTB.Enabled = true; 
        }

        private void DeleteBTN_Click(object sender, EventArgs e)
        {
            if (dataGridViewX1.SelectedRows.Count != 1) { return; }
            string cid = dataGridViewX1.SelectedRows[0].Cells[0].Value.ToString();
            if (MessageBox.Show("Are you Sure?", "Confirmation", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No) { return; }
            new MyOleDB().OleDbNonQuery("delete from Products where pid=" + cid);
            Search(SearchTB.Text);
        }

        private void Products_Load(object sender, EventArgs e)
        {
            DataTable t = new MyOleDB().ResultQuery("Select ShopName from Shops").Tables[0];
            if (t.Rows.Count == 0) { return; }
            foreach (DataRow r in t.Rows) { ShopCB.Items.Add(r[0].ToString()); }
            
        }

        private void CancleBTN_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
