﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CanteenFingerPrintBillingUtility
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void ProductsBTN_Click(object sender, EventArgs e)
        {
            new Products().ShowDialog();
            LoadProducts();
        }
        private void LoadProducts()
        {
            
            ProductListCB.Items.Clear();
            string cmd = "select Pname,Pcode,Quantity,Price,pid from products";
            DataTable t = new MyOleDB().ResultQuery(cmd).Tables[0];
            if (t.Rows.Count == 0) { return; }

            foreach (DataRow r in t.Rows) { ProductListCB.Items.Add(r[0].ToString() + " - " + r[1].ToString() + " - (" + r[2].ToString() + ") - " + r[3].ToString() + " -" + r[4].ToString()); }

        }

    }
}
