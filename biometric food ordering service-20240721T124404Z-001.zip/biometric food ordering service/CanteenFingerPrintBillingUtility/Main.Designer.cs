﻿namespace CanteenFingerPrintBillingUtility
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.regularExpressionValidator1 = new DevComponents.DotNetBar.Validator.RegularExpressionValidator();
            this.InfoL = new DevComponents.DotNetBar.LabelX();
            this.superValidator1 = new DevComponents.DotNetBar.Validator.SuperValidator();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.highlighter1 = new DevComponents.DotNetBar.Validator.Highlighter();
            this.QuantityTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.regularExpressionValidator2 = new DevComponents.DotNetBar.Validator.RegularExpressionValidator();
            this.DoneBTN = new DevComponents.DotNetBar.ButtonX();
            this.GetUserInfoBTN = new DevComponents.DotNetBar.ButtonX();
            this.AddToCartBTN = new DevComponents.DotNetBar.ButtonX();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX3 = new DevComponents.DotNetBar.ButtonX();
            this.SettingBTN = new DevComponents.DotNetBar.ButtonX();
            this.ViewRecordBTN = new DevComponents.DotNetBar.ButtonX();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.reflectionLabel1 = new DevComponents.DotNetBar.Controls.ReflectionLabel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.AddEditRecordsBTN = new DevComponents.DotNetBar.ButtonX();
            this.ProductsBTN = new DevComponents.DotNetBar.ButtonX();
            this.reflectionLabel2 = new DevComponents.DotNetBar.Controls.ReflectionLabel();
            this.ProductListCB = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.BalanceL = new DevComponents.DotNetBar.LabelX();
            this.TotalL = new DevComponents.DotNetBar.LabelX();
            this.listViewEx1 = new DevComponents.DotNetBar.Controls.ListViewEx();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.MobileL = new DevComponents.DotNetBar.LabelX();
            this.NameL = new DevComponents.DotNetBar.LabelX();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // regularExpressionValidator1
            // 
            this.regularExpressionValidator1.ErrorMessage = "Your error message here.";
            this.regularExpressionValidator1.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            this.regularExpressionValidator1.ValidationExpression = "[0-9]";
            // 
            // InfoL
            // 
            this.InfoL.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.InfoL.BackgroundStyle.Class = "";
            this.InfoL.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.InfoL.Location = new System.Drawing.Point(233, 442);
            this.InfoL.Name = "InfoL";
            this.InfoL.Size = new System.Drawing.Size(289, 23);
            this.InfoL.TabIndex = 22;
            // 
            // superValidator1
            // 
            this.superValidator1.ErrorProvider = this.errorProvider1;
            this.superValidator1.Highlighter = this.highlighter1;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            this.errorProvider1.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProvider1.Icon")));
            // 
            // QuantityTB
            // 
            // 
            // 
            // 
            this.QuantityTB.Border.Class = "TextBoxBorder";
            this.QuantityTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.QuantityTB.Location = new System.Drawing.Point(703, 32);
            this.QuantityTB.MaxLength = 5;
            this.QuantityTB.Name = "QuantityTB";
            this.QuantityTB.Size = new System.Drawing.Size(107, 22);
            this.QuantityTB.TabIndex = 29;
            this.superValidator1.SetValidator1(this.QuantityTB, this.regularExpressionValidator2);
            // 
            // regularExpressionValidator2
            // 
            this.regularExpressionValidator2.ErrorMessage = "Your error message here.";
            this.regularExpressionValidator2.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            this.regularExpressionValidator2.ValidationExpression = "[0-9]";
            // 
            // DoneBTN
            // 
            this.DoneBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.DoneBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.DoneBTN.Location = new System.Drawing.Point(818, 416);
            this.DoneBTN.Name = "DoneBTN";
            this.DoneBTN.Size = new System.Drawing.Size(154, 56);
            this.DoneBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DoneBTN.TabIndex = 31;
            this.DoneBTN.Text = "Done";
            // 
            // GetUserInfoBTN
            // 
            this.GetUserInfoBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.GetUserInfoBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.GetUserInfoBTN.Location = new System.Drawing.Point(4, 52);
            this.GetUserInfoBTN.Name = "GetUserInfoBTN";
            this.GetUserInfoBTN.Size = new System.Drawing.Size(215, 53);
            this.GetUserInfoBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.GetUserInfoBTN.TabIndex = 30;
            this.GetUserInfoBTN.Text = "Get User Info / Finger Scan";
            // 
            // AddToCartBTN
            // 
            this.AddToCartBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.AddToCartBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.AddToCartBTN.Location = new System.Drawing.Point(818, 23);
            this.AddToCartBTN.Name = "AddToCartBTN";
            this.AddToCartBTN.Size = new System.Drawing.Size(154, 44);
            this.AddToCartBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.AddToCartBTN.TabIndex = 23;
            this.AddToCartBTN.Text = "Add to Cart";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(4, 249);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 217);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Location = new System.Drawing.Point(38, 436);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(103, 36);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 67;
            this.buttonX2.Text = "buttonX2";
            this.buttonX2.Visible = false;
            // 
            // buttonX3
            // 
            this.buttonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX3.Location = new System.Drawing.Point(10, 311);
            this.buttonX3.Name = "buttonX3";
            this.buttonX3.Size = new System.Drawing.Size(204, 54);
            this.buttonX3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX3.TabIndex = 62;
            this.buttonX3.Text = "Exit";
            // 
            // SettingBTN
            // 
            this.SettingBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.SettingBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.SettingBTN.Location = new System.Drawing.Point(10, 191);
            this.SettingBTN.Name = "SettingBTN";
            this.SettingBTN.Size = new System.Drawing.Size(204, 54);
            this.SettingBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.SettingBTN.TabIndex = 63;
            this.SettingBTN.Text = "Settings";
            // 
            // ViewRecordBTN
            // 
            this.ViewRecordBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.ViewRecordBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.ViewRecordBTN.Location = new System.Drawing.Point(10, 132);
            this.ViewRecordBTN.Name = "ViewRecordBTN";
            this.ViewRecordBTN.Size = new System.Drawing.Size(204, 54);
            this.ViewRecordBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ViewRecordBTN.TabIndex = 66;
            this.ViewRecordBTN.Text = "View Records";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.reflectionLabel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1210, 570);
            this.splitContainer1.SplitterDistance = 86;
            this.splitContainer1.TabIndex = 81;
            // 
            // reflectionLabel1
            // 
            // 
            // 
            // 
            this.reflectionLabel1.BackgroundStyle.Class = "";
            this.reflectionLabel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reflectionLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(152)))), ((int)(((byte)(120)))));
            this.reflectionLabel1.Location = new System.Drawing.Point(15, 11);
            this.reflectionLabel1.Margin = new System.Windows.Forms.Padding(4);
            this.reflectionLabel1.Name = "reflectionLabel1";
            this.reflectionLabel1.Size = new System.Drawing.Size(355, 58);
            this.reflectionLabel1.TabIndex = 1;
            this.reflectionLabel1.Text = "Biometric Food Ordering Service";
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.buttonX4);
            this.splitContainer2.Panel1.Controls.Add(this.buttonX2);
            this.splitContainer2.Panel1.Controls.Add(this.AddEditRecordsBTN);
            this.splitContainer2.Panel1.Controls.Add(this.buttonX3);
            this.splitContainer2.Panel1.Controls.Add(this.SettingBTN);
            this.splitContainer2.Panel1.Controls.Add(this.ProductsBTN);
            this.splitContainer2.Panel1.Controls.Add(this.ViewRecordBTN);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.reflectionLabel2);
            this.splitContainer2.Panel2.Controls.Add(this.AddToCartBTN);
            this.splitContainer2.Panel2.Controls.Add(this.InfoL);
            this.splitContainer2.Panel2.Controls.Add(this.DoneBTN);
            this.splitContainer2.Panel2.Controls.Add(this.pictureBox1);
            this.splitContainer2.Panel2.Controls.Add(this.GetUserInfoBTN);
            this.splitContainer2.Panel2.Controls.Add(this.ProductListCB);
            this.splitContainer2.Panel2.Controls.Add(this.QuantityTB);
            this.splitContainer2.Panel2.Controls.Add(this.labelX2);
            this.splitContainer2.Panel2.Controls.Add(this.BalanceL);
            this.splitContainer2.Panel2.Controls.Add(this.TotalL);
            this.splitContainer2.Panel2.Controls.Add(this.listViewEx1);
            this.splitContainer2.Panel2.Controls.Add(this.labelX1);
            this.splitContainer2.Panel2.Controls.Add(this.MobileL);
            this.splitContainer2.Panel2.Controls.Add(this.NameL);
            this.splitContainer2.Size = new System.Drawing.Size(1210, 480);
            this.splitContainer2.SplitterDistance = 224;
            this.splitContainer2.TabIndex = 0;
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX4.Location = new System.Drawing.Point(10, 251);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(204, 54);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX4.TabIndex = 68;
            this.buttonX4.Text = "Message Box";
            // 
            // AddEditRecordsBTN
            // 
            this.AddEditRecordsBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.AddEditRecordsBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.AddEditRecordsBTN.Location = new System.Drawing.Point(10, 13);
            this.AddEditRecordsBTN.Name = "AddEditRecordsBTN";
            this.AddEditRecordsBTN.Size = new System.Drawing.Size(204, 54);
            this.AddEditRecordsBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.AddEditRecordsBTN.TabIndex = 65;
            this.AddEditRecordsBTN.Text = "Clients";
            // 
            // ProductsBTN
            // 
            this.ProductsBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.ProductsBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.ProductsBTN.Location = new System.Drawing.Point(10, 73);
            this.ProductsBTN.Name = "ProductsBTN";
            this.ProductsBTN.Size = new System.Drawing.Size(204, 54);
            this.ProductsBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ProductsBTN.TabIndex = 64;
            this.ProductsBTN.Text = "Products";
            this.ProductsBTN.Click += new System.EventHandler(this.ProductsBTN_Click);
            // 
            // reflectionLabel2
            // 
            this.reflectionLabel2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.reflectionLabel2.BackgroundStyle.Class = "";
            this.reflectionLabel2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionLabel2.Location = new System.Drawing.Point(5, 5);
            this.reflectionLabel2.Margin = new System.Windows.Forms.Padding(4);
            this.reflectionLabel2.Name = "reflectionLabel2";
            this.reflectionLabel2.Size = new System.Drawing.Size(170, 41);
            this.reflectionLabel2.TabIndex = 17;
            this.reflectionLabel2.Text = "<b><font size=\"+4\"><i></i><font color=\"#cc8833\">\r\nSellingOperations\r\n</font></fon" +
    "t></b>";
            // 
            // ProductListCB
            // 
            this.ProductListCB.DisplayMember = "Text";
            this.ProductListCB.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ProductListCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ProductListCB.FormattingEnabled = true;
            this.ProductListCB.ItemHeight = 16;
            this.ProductListCB.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2});
            this.ProductListCB.Location = new System.Drawing.Point(365, 32);
            this.ProductListCB.Name = "ProductListCB";
            this.ProductListCB.Size = new System.Drawing.Size(258, 22);
            this.ProductListCB.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ProductListCB.TabIndex = 1;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "Solid";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "Liquid";
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(629, 31);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(68, 23);
            this.labelX2.TabIndex = 2;
            this.labelX2.Text = " Quantity";
            // 
            // BalanceL
            // 
            this.BalanceL.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.BalanceL.BackgroundStyle.Class = "";
            this.BalanceL.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.BalanceL.Location = new System.Drawing.Point(4, 209);
            this.BalanceL.Name = "BalanceL";
            this.BalanceL.Size = new System.Drawing.Size(198, 23);
            this.BalanceL.TabIndex = 28;
            // 
            // TotalL
            // 
            this.TotalL.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.TotalL.BackgroundStyle.Class = "";
            this.TotalL.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.TotalL.Location = new System.Drawing.Point(257, 413);
            this.TotalL.Name = "TotalL";
            this.TotalL.Size = new System.Drawing.Size(419, 23);
            this.TotalL.TabIndex = 25;
            this.TotalL.Text = "Total Products = 00     Bill Payable = ";
            // 
            // listViewEx1
            // 
            // 
            // 
            // 
            this.listViewEx1.Border.Class = "ListViewBorder";
            this.listViewEx1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.listViewEx1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listViewEx1.ContextMenuStrip = this.contextMenuStrip1;
            this.listViewEx1.FullRowSelect = true;
            this.listViewEx1.Location = new System.Drawing.Point(257, 73);
            this.listViewEx1.Name = "listViewEx1";
            this.listViewEx1.Size = new System.Drawing.Size(715, 337);
            this.listViewEx1.TabIndex = 24;
            this.listViewEx1.UseCompatibleStateImageBehavior = false;
            this.listViewEx1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Product Name";
            this.columnHeader1.Width = 326;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Quantity";
            this.columnHeader2.Width = 74;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Price Per Unit";
            this.columnHeader3.Width = 126;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Total Price /-";
            this.columnHeader4.Width = 102;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "ID";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.toolStripMenuItem1.Text = "Delete";
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(256, 31);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(103, 23);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Select Product";
            // 
            // MobileL
            // 
            this.MobileL.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.MobileL.BackgroundStyle.Class = "";
            this.MobileL.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.MobileL.Location = new System.Drawing.Point(4, 180);
            this.MobileL.Name = "MobileL";
            this.MobileL.Size = new System.Drawing.Size(138, 23);
            this.MobileL.TabIndex = 27;
            // 
            // NameL
            // 
            this.NameL.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.NameL.BackgroundStyle.Class = "";
            this.NameL.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.NameL.Location = new System.Drawing.Point(4, 151);
            this.NameL.Name = "NameL";
            this.NameL.Size = new System.Drawing.Size(90, 23);
            this.NameL.TabIndex = 26;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 570);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Validator.RegularExpressionValidator regularExpressionValidator1;
        private DevComponents.DotNetBar.LabelX InfoL;
        private DevComponents.DotNetBar.Validator.SuperValidator superValidator1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX AddEditRecordsBTN;
        private DevComponents.DotNetBar.ButtonX buttonX3;
        private DevComponents.DotNetBar.ButtonX SettingBTN;
        private DevComponents.DotNetBar.ButtonX ProductsBTN;
        private DevComponents.DotNetBar.ButtonX ViewRecordBTN;
        private DevComponents.DotNetBar.Controls.ReflectionLabel reflectionLabel2;
        private DevComponents.DotNetBar.ButtonX AddToCartBTN;
        private DevComponents.DotNetBar.ButtonX DoneBTN;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevComponents.DotNetBar.ButtonX GetUserInfoBTN;
        private DevComponents.DotNetBar.Controls.ComboBoxEx ProductListCB;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.DotNetBar.Controls.TextBoxX QuantityTB;
        private DevComponents.DotNetBar.Validator.RegularExpressionValidator regularExpressionValidator2;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX BalanceL;
        private DevComponents.DotNetBar.LabelX TotalL;
        private DevComponents.DotNetBar.Controls.ListViewEx listViewEx1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX MobileL;
        private DevComponents.DotNetBar.LabelX NameL;
        private DevComponents.DotNetBar.Validator.Highlighter highlighter1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private DevComponents.DotNetBar.Controls.ReflectionLabel reflectionLabel1;

    }
}