﻿using System;
using System.Data;

using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;

namespace CanteenFingerPrintBillingUtility
{
    class MyOleDB
    {
        
        public static string OleDbConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\DB.accdb;";

       

        public bool TestOleDbConnection()
        {
            try
            {
                using (OleDbConnection cn = GetOleDbActiveConnection())
                {
                    //bool results = cn.State.Equals( ConnectionState.Open);
                    cn.Close();
                    bool results = true;
                    MessageBox.Show("Success!!! ");
                    return results;
                }

            }
            catch { MessageBox.Show("Database Connection Error! "); return false; }
        }

        public OleDbConnection GetOleDbActiveConnection()
        {
            OleDbConnection cn = new OleDbConnection(OleDbConnectionString);
            cn.Open();
            return cn;
        }

        public bool OleDbNonQuery(string Query)
        {
            using (OleDbConnection cn = GetOleDbActiveConnection())
            {

                bool s = OleDbNonQuery(Query, cn);
                cn.Close(); cn.Dispose();
                return s;

            }
        }
        public bool OleDbNonQuery(string Query, OleDbConnection cn)
        {
            try
            {
                new OleDbCommand(Query, cn).ExecuteNonQuery();
                return true;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return false; }

        }

        public string OleDbScalarQuery(string Query)
        {
            using (OleDbConnection cn = GetOleDbActiveConnection())
            {

                string s = OleDbScalarQuery(Query, cn);
                cn.Close(); cn.Dispose();
                return s;

            }
        }
        public string OleDbScalarQuery(string Query, OleDbConnection cn)
        {
            try
            {
                return new OleDbCommand(Query, cn).ExecuteScalar().ToString();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return null; }
        }


        public DataSet ResultQuery(string Query)
        {
            using (OleDbConnection cn = GetOleDbActiveConnection())
            {
                DataSet ds = ResultQuery(Query, cn);
                cn.Close(); cn.Dispose();
                return ds;
            }
        }
        public DataSet ResultQuery(string Query, OleDbConnection cn)
        {
            try
            {
                DataSet ds = new DataSet();
                new OleDbDataAdapter(Query, cn).Fill(ds);
                return ds;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); return null; }

        }
        public List<string> ColumnQuery(string Query)
        {
            using (OleDbConnection cn = GetOleDbActiveConnection())
            {
                List<string> List = ColumnQuery(Query, cn);
                cn.Close(); cn.Dispose();
                return List;                
            }
        }
        public List<string> ColumnQuery(string Query, OleDbConnection cn)
        {
            DataSet ds = new DataSet(); 
            List<string> List = new List<string>();
            new OleDbDataAdapter(Query, cn).Fill(ds);
            foreach (DataRow r in ds.Tables[0].Rows) { List.Add(r[0].ToString()); }
            return List;

        }
         public List<string> RowQuery(string Query)
         {
             List<string> List = new List<string>();
             using (OleDbConnection cn = GetOleDbActiveConnection())
             {
                 DataSet ds = RowQuery(Query, cn);
                 cn.Close(); cn.Dispose();

                 foreach ( DataColumn c in ds.Tables[0].Columns) { List.Add(ds.Tables[0].Rows[0][c].ToString()); }
             }
             return List;
         }
         public DataSet RowQuery(string Query, OleDbConnection cn)
         {
             DataSet ds = new DataSet();
             new OleDbDataAdapter(Query, cn).Fill(ds);
             return ds;

         }

         public static DataTable FullMonthAttendanceTable(DateTime dt)
         {
             DataTable t = new DataTable("FullMonthAttendanceTable");
             int days = DateTime.DaysInMonth(dt.Year, dt.Month);
             for (int i = 1; i <= days; i++) { t.Columns.Add(i.ToString()); }
             return t;
             
         }



        //----------------------- MyOleDb -----------------------


        //public bool TestMyOleDbConnection()
        //{
        //    try
        //    {
        //        using (MyOleDbConnection cn = GetMyOleDbActiveConnection())
        //        {
        //            bool results = cn.State.Equals(ConnectionState.Open);
        //            cn.Close();
        //            return results;
        //        }

        //    }
        //    catch { return false; }
        //}
        //public MyOleDbConnection GetMyOleDbActiveConnection()
        //{
        //    MyOleDbConnection cn = new MyOleDbConnection(MyOleDbConnectionString);
        //    cn.Open();
        //    return cn;
        //}
        //public DataSet ResultQuery(string Query)
        //{
        //    using (MyOleDbConnection cn = GetMyOleDbActiveConnection())
        //    {
        //        DataSet ds = ResultQuery(Query, cn);
        //        cn.Close(); cn.Dispose();
        //        return ds;
        //    }
        //}
        //public DataSet ResultQuery(string Query, MyOleDbConnection cn)
        //{
        //    DataSet ds = new DataSet();
        //    new OleDbDataAdapter(Query, cn).Fill(ds);
        //    return ds;

        //}
        //public string ScalarQuery(string Query)
        //{
        //    using (MyOleDbConnection cn = GetMyOleDbActiveConnection())
        //    {

        //        string s = ScalarQuery(Query, cn);
        //        cn.Close(); cn.Dispose();
        //        return s;

        //    }
        //}
        //public string ScalarQuery(string Query, MyOleDbConnection cn)
        //{
        //    return new MyOleDbCommand(Query, cn).ExecuteScalar().ToString();
        //}
        //public bool NonQuery(string Query)
        //{
        //    using (MyOleDbConnection cn = GetMyOleDbActiveConnection())
        //    {

        //        bool s = NonQuery(Query, cn);
        //        cn.Close(); cn.Dispose();
        //        return s;

        //    }
        //}
        //public bool NonQuery(string Query, MyOleDbConnection cn)
        //{
        //    try
        //    {
        //        new MyOleDbCommand(Query, cn).ExecuteNonQuery();
        //        return true;
        //    }
        //    catch { return false; }

        //}
        //public static bool CheckDB()
        //{
        //    //bool results = true;

        //    List<string> l = new List<string>();
        //    l.AddRange(DBTables);
        //    DataTable t = new MyDB().ResultQuery("show Tables").Tables[0];
        //    if (l.Count != t.Rows.Count) { return false; }
        //    foreach (DataRow r in t.Rows)
        //    {
        //        string Tab = r[0].ToString();
        //        if (!l.Contains(Tab)) { return false; }
        //    }
        //    return true;
        //}
        //public static void SetDB()
        //{
        //    System.IO.StreamReader sr = new System.IO.StreamReader(@"DataBase.OleDb");
        //    string s = sr.ReadToEnd();
        //    sr.Close(); sr.Dispose();

        //    if (new MyDB().NonQuery(s))
        //    {
        //        System.Windows.Forms.MessageBox.Show("Database Sattled");
        //    }
        //}
    }
}
