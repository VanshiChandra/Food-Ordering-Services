﻿namespace CanteenFingerPrintBillingUtility
{
    partial class Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Products));
            this.label4 = new System.Windows.Forms.Label();
            this.ShopCB = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.reflectionLabel1 = new DevComponents.DotNetBar.Controls.ReflectionLabel();
            this.DeleteBTN = new DevComponents.DotNetBar.ButtonX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.SearchTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.SearchBTN = new DevComponents.DotNetBar.ButtonX();
            this.dataGridViewX1 = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.reflectionLabel3 = new DevComponents.DotNetBar.Controls.ReflectionLabel();
            this.ResetBTN = new DevComponents.DotNetBar.ButtonX();
            this.SearchPCode = new DevComponents.DotNetBar.ButtonX();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CancleBTN = new DevComponents.DotNetBar.ButtonX();
            this.label6 = new System.Windows.Forms.Label();
            this.PCodeTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.DoneBTN = new DevComponents.DotNetBar.ButtonX();
            this.label15 = new System.Windows.Forms.Label();
            this.PNameTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.QuantityTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.PriceTB = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.highlighter1 = new DevComponents.DotNetBar.Validator.Highlighter();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.regularExpressionValidator2 = new DevComponents.DotNetBar.Validator.RegularExpressionValidator();
            this.regularExpressionValidator3 = new DevComponents.DotNetBar.Validator.RegularExpressionValidator();
            this.regularExpressionValidator1 = new DevComponents.DotNetBar.Validator.RegularExpressionValidator();
            this.superValidator1 = new DevComponents.DotNetBar.Validator.SuperValidator();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 310);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 16);
            this.label4.TabIndex = 199;
            this.label4.Text = "ShopName";
            this.label4.Visible = false;
            // 
            // ShopCB
            // 
            this.ShopCB.DisplayMember = "Text";
            this.ShopCB.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ShopCB.FormattingEnabled = true;
            this.ShopCB.ItemHeight = 16;
            this.ShopCB.Location = new System.Drawing.Point(131, 304);
            this.ShopCB.Name = "ShopCB";
            this.ShopCB.Size = new System.Drawing.Size(159, 22);
            this.ShopCB.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ShopCB.TabIndex = 198;
            this.ShopCB.Visible = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.reflectionLabel3);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.ShopCB);
            this.splitContainer1.Panel2.Controls.Add(this.ResetBTN);
            this.splitContainer1.Panel2.Controls.Add(this.SearchPCode);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.CancleBTN);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.PCodeTB);
            this.splitContainer1.Panel2.Controls.Add(this.DoneBTN);
            this.splitContainer1.Panel2.Controls.Add(this.label15);
            this.splitContainer1.Panel2.Controls.Add(this.PNameTB);
            this.splitContainer1.Panel2.Controls.Add(this.QuantityTB);
            this.splitContainer1.Panel2.Controls.Add(this.PriceTB);
            this.splitContainer1.Size = new System.Drawing.Size(1163, 694);
            this.splitContainer1.SplitterDistance = 785;
            this.splitContainer1.TabIndex = 198;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.reflectionLabel1);
            this.splitContainer2.Panel1.Controls.Add(this.DeleteBTN);
            this.splitContainer2.Panel1.Controls.Add(this.labelX1);
            this.splitContainer2.Panel1.Controls.Add(this.SearchTB);
            this.splitContainer2.Panel1.Controls.Add(this.SearchBTN);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dataGridViewX1);
            this.splitContainer2.Size = new System.Drawing.Size(783, 692);
            this.splitContainer2.SplitterDistance = 104;
            this.splitContainer2.TabIndex = 0;
            // 
            // reflectionLabel1
            // 
            // 
            // 
            // 
            this.reflectionLabel1.BackgroundStyle.Class = "";
            this.reflectionLabel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reflectionLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(152)))), ((int)(((byte)(120)))));
            this.reflectionLabel1.Location = new System.Drawing.Point(12, 0);
            this.reflectionLabel1.Margin = new System.Windows.Forms.Padding(4);
            this.reflectionLabel1.Name = "reflectionLabel1";
            this.reflectionLabel1.Size = new System.Drawing.Size(148, 66);
            this.reflectionLabel1.TabIndex = 197;
            this.reflectionLabel1.Text = "Products";
            // 
            // DeleteBTN
            // 
            this.DeleteBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.DeleteBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.DeleteBTN.Location = new System.Drawing.Point(670, 27);
            this.DeleteBTN.Name = "DeleteBTN";
            this.DeleteBTN.Size = new System.Drawing.Size(105, 52);
            this.DeleteBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DeleteBTN.TabIndex = 196;
            this.DeleteBTN.Text = "Delete";
            this.DeleteBTN.Click += new System.EventHandler(this.DeleteBTN_Click);
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(213, 44);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(137, 23);
            this.labelX1.TabIndex = 3;
            this.labelX1.Text = "Product Name /  Code";
            // 
            // SearchTB
            // 
            // 
            // 
            // 
            this.SearchTB.Border.Class = "TextBoxBorder";
            this.SearchTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.SearchTB.Location = new System.Drawing.Point(356, 44);
            this.SearchTB.Name = "SearchTB";
            this.SearchTB.Size = new System.Drawing.Size(159, 22);
            this.SearchTB.TabIndex = 2;
            // 
            // SearchBTN
            // 
            this.SearchBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.SearchBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.SearchBTN.Location = new System.Drawing.Point(531, 27);
            this.SearchBTN.Name = "SearchBTN";
            this.SearchBTN.Size = new System.Drawing.Size(105, 52);
            this.SearchBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.SearchBTN.TabIndex = 0;
            this.SearchBTN.Text = "Search";
            this.SearchBTN.Click += new System.EventHandler(this.SearchBTN_Click);
            // 
            // dataGridViewX1
            // 
            this.dataGridViewX1.AllowUserToAddRows = false;
            this.dataGridViewX1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dataGridViewX1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewX1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewX1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewX1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewX1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewX1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(213)))), ((int)(((byte)(198)))));
            this.dataGridViewX1.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewX1.Name = "dataGridViewX1";
            this.dataGridViewX1.ReadOnly = true;
            this.dataGridViewX1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewX1.Size = new System.Drawing.Size(783, 584);
            this.dataGridViewX1.TabIndex = 0;
            this.dataGridViewX1.DoubleClick += new System.EventHandler(this.dataGridViewX1_DoubleClick);
            // 
            // reflectionLabel3
            // 
            // 
            // 
            // 
            this.reflectionLabel3.BackgroundStyle.Class = "";
            this.reflectionLabel3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reflectionLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(152)))), ((int)(((byte)(120)))));
            this.reflectionLabel3.Location = new System.Drawing.Point(14, 12);
            this.reflectionLabel3.Margin = new System.Windows.Forms.Padding(4);
            this.reflectionLabel3.Name = "reflectionLabel3";
            this.reflectionLabel3.Size = new System.Drawing.Size(263, 42);
            this.reflectionLabel3.TabIndex = 200;
            this.reflectionLabel3.Text = "Add / Update Products";
            // 
            // ResetBTN
            // 
            this.ResetBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.ResetBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.ResetBTN.Location = new System.Drawing.Point(14, 345);
            this.ResetBTN.Name = "ResetBTN";
            this.ResetBTN.Size = new System.Drawing.Size(338, 49);
            this.ResetBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ResetBTN.TabIndex = 197;
            this.ResetBTN.Text = "Reset Entries / Add New Product";
            this.ResetBTN.Click += new System.EventHandler(this.ResetBTN_Click);
            // 
            // SearchPCode
            // 
            this.SearchPCode.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.SearchPCode.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.SearchPCode.Location = new System.Drawing.Point(303, 170);
            this.SearchPCode.Name = "SearchPCode";
            this.SearchPCode.Size = new System.Drawing.Size(48, 24);
            this.SearchPCode.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.SearchPCode.TabIndex = 3;
            this.SearchPCode.Text = "Search";
            this.SearchPCode.Click += new System.EventHandler(this.SearchPCode_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 216);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 179;
            this.label3.Text = "Quantity";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 170);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 16);
            this.label2.TabIndex = 178;
            this.label2.Text = "Product Code";
            // 
            // CancleBTN
            // 
            this.CancleBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.CancleBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.CancleBTN.Location = new System.Drawing.Point(14, 455);
            this.CancleBTN.Name = "CancleBTN";
            this.CancleBTN.Size = new System.Drawing.Size(170, 49);
            this.CancleBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.CancleBTN.TabIndex = 7;
            this.CancleBTN.Text = "Cancle";
            this.CancleBTN.Click += new System.EventHandler(this.CancleBTN_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 261);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 16);
            this.label6.TabIndex = 180;
            this.label6.Text = "Price/ Unit Rate";
            // 
            // PCodeTB
            // 
            // 
            // 
            // 
            this.PCodeTB.Border.Class = "TextBoxBorder";
            this.PCodeTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PCodeTB.Location = new System.Drawing.Point(131, 170);
            this.PCodeTB.Name = "PCodeTB";
            this.PCodeTB.Size = new System.Drawing.Size(159, 22);
            this.PCodeTB.TabIndex = 2;
            this.superValidator1.SetValidator1(this.PCodeTB, this.regularExpressionValidator3);
            // 
            // DoneBTN
            // 
            this.DoneBTN.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.DoneBTN.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.DoneBTN.Location = new System.Drawing.Point(14, 400);
            this.DoneBTN.Name = "DoneBTN";
            this.DoneBTN.Size = new System.Drawing.Size(338, 49);
            this.DoneBTN.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DoneBTN.TabIndex = 6;
            this.DoneBTN.Text = "Done";
            this.DoneBTN.Click += new System.EventHandler(this.DoneBTN_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(23, 130);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 16);
            this.label15.TabIndex = 182;
            this.label15.Text = "Product Name";
            // 
            // PNameTB
            // 
            // 
            // 
            // 
            this.PNameTB.Border.Class = "TextBoxBorder";
            this.PNameTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PNameTB.Location = new System.Drawing.Point(131, 130);
            this.PNameTB.Name = "PNameTB";
            this.PNameTB.Size = new System.Drawing.Size(159, 22);
            this.PNameTB.TabIndex = 1;
            // 
            // QuantityTB
            // 
            // 
            // 
            // 
            this.QuantityTB.Border.Class = "TextBoxBorder";
            this.QuantityTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.QuantityTB.Location = new System.Drawing.Point(131, 216);
            this.QuantityTB.MaxLength = 5;
            this.QuantityTB.Name = "QuantityTB";
            this.QuantityTB.Size = new System.Drawing.Size(159, 22);
            this.QuantityTB.TabIndex = 4;
            this.superValidator1.SetValidator1(this.QuantityTB, this.regularExpressionValidator1);
            // 
            // PriceTB
            // 
            // 
            // 
            // 
            this.PriceTB.Border.Class = "TextBoxBorder";
            this.PriceTB.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PriceTB.Location = new System.Drawing.Point(131, 259);
            this.PriceTB.MaxLength = 10;
            this.PriceTB.Name = "PriceTB";
            this.PriceTB.Size = new System.Drawing.Size(159, 22);
            this.PriceTB.TabIndex = 5;
            this.superValidator1.SetValidator1(this.PriceTB, this.regularExpressionValidator2);
            // 
            // highlighter1
            // 
            this.highlighter1.ContainerControl = this;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            this.errorProvider1.Icon = ((System.Drawing.Icon)(resources.GetObject("errorProvider1.Icon")));
            // 
            // regularExpressionValidator2
            // 
            this.regularExpressionValidator2.ErrorMessage = "Your error message here.";
            this.regularExpressionValidator2.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            this.regularExpressionValidator2.ValidationExpression = "^[0-9.]{1,10}$";
            // 
            // regularExpressionValidator3
            // 
            this.regularExpressionValidator3.ErrorMessage = "Your error message here.";
            this.regularExpressionValidator3.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            this.regularExpressionValidator3.ValidationExpression = "[A-Ba-b0-9.]";
            // 
            // regularExpressionValidator1
            // 
            this.regularExpressionValidator1.ErrorMessage = "Your error message here.";
            this.regularExpressionValidator1.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            this.regularExpressionValidator1.ValidationExpression = "\\d";
            // 
            // superValidator1
            // 
            this.superValidator1.ContainerControl = this;
            this.superValidator1.ErrorProvider = this.errorProvider1;
            this.superValidator1.Highlighter = this.highlighter1;
            // 
            // Products
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 694);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Products";
            this.Text = "Products";
            this.Load += new System.EventHandler(this.Products_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private DevComponents.DotNetBar.Controls.ComboBoxEx ShopCB;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private DevComponents.DotNetBar.ButtonX DeleteBTN;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX SearchTB;
        private DevComponents.DotNetBar.ButtonX SearchBTN;
        private DevComponents.DotNetBar.Controls.DataGridViewX dataGridViewX1;
        private DevComponents.DotNetBar.ButtonX ResetBTN;
        private DevComponents.DotNetBar.ButtonX SearchPCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private DevComponents.DotNetBar.ButtonX CancleBTN;
        private System.Windows.Forms.Label label6;
        private DevComponents.DotNetBar.Controls.TextBoxX PCodeTB;
        private DevComponents.DotNetBar.Validator.SuperValidator superValidator1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private DevComponents.DotNetBar.Validator.Highlighter highlighter1;
        private DevComponents.DotNetBar.Validator.RegularExpressionValidator regularExpressionValidator3;
        private DevComponents.DotNetBar.ButtonX DoneBTN;
        private System.Windows.Forms.Label label15;
        private DevComponents.DotNetBar.Controls.TextBoxX PNameTB;
        private DevComponents.DotNetBar.Controls.TextBoxX QuantityTB;
        private DevComponents.DotNetBar.Validator.RegularExpressionValidator regularExpressionValidator1;
        private DevComponents.DotNetBar.Controls.TextBoxX PriceTB;
        private DevComponents.DotNetBar.Validator.RegularExpressionValidator regularExpressionValidator2;
        private DevComponents.DotNetBar.Controls.ReflectionLabel reflectionLabel1;
        private DevComponents.DotNetBar.Controls.ReflectionLabel reflectionLabel3;
    }
}